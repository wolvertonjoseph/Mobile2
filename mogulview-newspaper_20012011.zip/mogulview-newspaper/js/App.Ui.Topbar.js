Ext.ns('App.Ui');
App.Ui.Topbar = Ext.extend(Ext.Toolbar, {
	initComponent: function() {
		var config = {
			title: 'Touch Events',
			dock: 'top',
			defaults: {
				ui: 'mask'
			},
			layout: 'hbox'
			/*
			items: [
				{
					xtype:'spacer',
					flex:1
				},
				{
					iconCls: 'add',
					scope: this
				}
			]*/
		};
		Ext.apply(this, config);
		App.Ui.Topbar.superclass.initComponent.call(this);
	}

});
Ext.reg('App.Ui.Topbar', App.Ui.Topbar);