Ext.setup(
	{
		tabletStartupScreen: 'images/sencha_ipad.png',
		phoneStartupScreen: 'images/sencha_iphone.png',
		//icon: 'icon.png',
		addGlossToIcon: false,
		onReady: App.bootstrap,
		scope: App
	}
);

