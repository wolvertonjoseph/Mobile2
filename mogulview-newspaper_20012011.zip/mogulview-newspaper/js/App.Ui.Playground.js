Ext.ns('App.Ui');
App.Ui.Playground = Ext.extend(Ext.Panel, {

	// @privat
	initComponent: function() {

		var config = {
			title: 'Playground',
			cls: 'table absolute',
			iconCls: 'favorites'

		};
		Ext.apply(this, config);

		App.Ui.Playground.superclass.initComponent.call(this);
	},

	// @private
	onRender : function(ct, position) {
		App.Ui.Playground.superclass.onRender.call(this, ct, position);
	},

	// @privat
	afterRender: function() {
		App.Ui.Playground.superclass.afterRender.call(this);

		// add event listener
		this.mon(
			this.el,
			{
//				touchstart: this.onTouchstart,
                                swipe:this.onSwipe,
				scope: this
			}
		);
	},

	/**
	 * on touch start
	 *
	 * @param {} event
	 * @param {} html
	 * @param {} obj
	 */
	onTouchstart: function(event, html, obj) {
		// if touch on the playground area creat a new box
		if (event.target.className == 'x-panel-body') {
			var newBox = new App.Ui.TouchBox({positionConf: event});
			this.add(newBox);
			this.doLayout();
		}
	},
        onSwipe: function(event, html, obj) {
		// if touch on the playground area creat a new box
                alert(event.type);
	}


});
Ext.reg('App.Ui.Playground', App.Ui.Playground);