Ext.ns('App.Ui');
App.Ui.Help = Ext.extend(Ext.Panel, {
	initComponent: function() {
		var config = {
			title: 'Help',
			cls: 'info',
			iconCls: 'bookmarks',
			scroll: 'vertical',
			layout: {
				type: 'vbox',
				align: 'stretch'
			},
			html: 'This example shows different touch events.<br /><br />' +
					'Following actions you can do on the <i>playground tab</i>:<br />' +
					'-> tap once: to create a new box<br />' +
					'-> touch the box and move you finger to bottom right to resize<br />' +
					'-> double tap: activate dragging<br />' +
					'-> next double tap: deactivate dragging<br />' +
					'-> pinch: make a fast pinch with to fingers to destroy the box<br />' +
					'<br /><br />Have lot of fun :-)'

		};
		Ext.apply(this, config);
		App.Ui.Help.superclass.initComponent.call(this);
	},

	// @private
	onRender : function(ct, position) {
		App.Ui.Help.superclass.onRender.call(this, ct, position);
	}
});
Ext.reg('App.Ui.Help', App.Ui.Help);