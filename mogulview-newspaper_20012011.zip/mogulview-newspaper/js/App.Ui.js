/**
 * UI base class of the application
 */
Ext.ns('App.Ui');
App.Ui = Ext.extend(Ext.TabPanel, {


	initComponent: function() {
		var config = {
			fullscreen: true,
			cls: 'background',
			animation: {
				type: 'flip',
				cover: true
			},
			tabBar: {
				dock: 'bottom',
				layout: {
					pack: 'center'
				}
			},
			items: [
				{
					xtype: 'App.Ui.Help'
				},
				{
					xtype: 'App.Ui.Playground'
				},
				{
					xtype: 'App.Ui.Info'
				}
			],
			dockedItems: [
				{
					xtype: 'App.Ui.Topbar'
				}
			]
		};
		Ext.apply(this, config);
		App.Ui.superclass.initComponent.call(this);
	}
});