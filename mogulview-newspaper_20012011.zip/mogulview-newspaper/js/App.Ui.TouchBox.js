Ext.ns('App.Ui');

App.Ui.TouchBox = Ext.extend(Ext.Container, {

	// @privat
	initComponent: function() {
		this.topbarHeight = 50;
		var config = {
			cls: 'box',
			draggable: false
		};
		Ext.apply(this, config, this.initialConfig);
		App.Ui.TouchBox.superclass.initComponent.call(this);
	},

	// @private
	onRender : function(ct, position) {
		App.Ui.TouchBox.superclass.onRender.call(this, ct, position);
		// add event listener
		this.on('dragend', this.onDragend, this);
		this.mon(
			this.el,
			{
				doubletap: this.onDoubleTap,
				touchmove: this.onTouchmove,
				touchstart: this.onTouchstart,
                                swipe:this.onSwipe,
				touchend: this.onTouchend,
				pinch: this.onPinch,
				scope: this
			}
		);


		this.setPosition(this.positionConf.pageX , this.positionConf.pageY - this.topbarHeight);
	},

	// @privat
	afterRender: function() {
		App.Ui.Playground.superclass.afterRender.call(this);

	},


	/**
	 * Adds the touch event listener
	 */
	addTouchEvents: function() {
		this.mon(
			this.el,
			{
				touchmove: this.onTouchmove,
				touchstart: this.onTouchstart,
                                swipe:this.onSwipe,
				touchend: this.onTouchend,
				pinch: this.onPinch,
				scope: this
			}
		);
	},

	/**
	 * remove the touch event listener
	 */
	removeTouchEvents: function() {
		this.mun(
			this.el,
			{
				touchmove: this.onTouchmove,
				touchstart: this.onTouchstart,
                                swipe:this.onSwipe,
				touchend: this.onTouchend,
				pinch: this.onPinch,
				scope: this
			}
		);
	},


	/**
	 * on double tap destroy the object
	 *
	 * @param {} event
	 * @param {} html
	 * @param {} obj
	 */
	onDoubleTap: function(event, html, obj) {

		if (typeof this.draggable == 'object') {
			// remove draggablity
			this.draggable.purgeListeners ();
			this.draggable.destroy();
			this.draggable = false;

			this.addTouchEvents();
		} else {
			this.removeTouchEvents();
			this.setDraggable(true);
		}
		this.updateInformations(event);
	},

	/**
	 * on touch start
	 *
	 * @param {} event
	 * @param {} html
	 * @param {} obj
	 */
	onTouchstart: function(event, html, obj) {
		this.updateInformations(event);
	},
         onSwipe: function(event, html, obj) {
		// if touch on the playground area creat a new box
                alert(event.type);
	},
	/**
	 * on touch move
	 *
	 * @param {} event
	 * @param {} html
	 * @param {} obj
	 */
	onTouchmove: function(event, html, obj) {
		this.setSize(event.deltaX, event.deltaY);
		this.updateInformations(event);
	},

	/**
	 * on touchend
	 *
	 * @param {} event
	 * @param {} html
	 * @param {} obj
	 */
	onTouchend: function(event, html, obj) {
		var size = this.getSize();
		// prevent to build min boxes while a single tap
		if (size.width < 20 && size.height < 20) {
			this.destroy();
		}
	},

	/**
	 * On dragen update box informations
	 * @param {} draggable
	 * @param {} event
	 */
	onDragend: function(draggable, event) {
		this.updateInformations(event);
	},

	/**
	 * On pinch destroy the object
	 *
	 * @param {} e
	 * @param {} el
	 * @param {} obj
	 */
	onPinch: function(e, el, obj) {
		this.removeTouchEvents();

		this.destroy();
		//el.style.webkitTransform = 'scale(' + e.scale + ')';

		/*
		this.setSize(
			this.getWidth() * (e.previousScale * e.scale),
			this.getHeight() * (e.previousScale * e.scale)

		);

		this.update(
			'e.scale: ' + e.scale + '<br>' +
			'e.deltaScale: ' + e.deltaScale + '<br>' +
			'e.previousScale: ' + e.previousScale + '<br>' +
			'e.deltaScale: ' + e.deltaScale + '<br>' +
			'e.distance: ' + e.distance + '<br>'
		);
		*/

	},

	/**
	 * Update Informations in container
	 */
	updateInformations: function(event) {
		this.update(
			String.format(
				'w: {0} h: {1}<br />' +
				'x: {2} y: {3}<br />' +
				'draggable: {4}',
				this.getWidth(),
				this.getHeight(),
				event.pageX,
				event.pageY,
				(typeof this.draggable == 'object' ? true : false)
			)
		);
	}
});
Ext.reg('App.Ui.TouchBox', App.Ui.TouchBox);