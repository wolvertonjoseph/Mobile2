Ext.ns('App.Ui');
App.Ui.Info = Ext.extend(Ext.Panel, {
	initComponent: function() {
		var config = {
			title: 'Info',
			cls: 'info',
			iconCls: 'info',
			scroll: 'vertical',
			layout: {
				type: 'vbox',
				align: 'stretch'
			},
			html: '&copy; Nils Dehl<br />' +
					'mail: <a href="mailto:mail@nils-dehl.de">mail@nils-dehl.de</a><br />' +
					'www: <a href="http://nils-dehl.de">http://nils-dehl.de</a><br /><br />' +
					'version: 1.0'
		};
		Ext.apply(this, config);
		App.Ui.Info.superclass.initComponent.call(this);
	},

	// @private
	onRender : function(ct, position) {
		App.Ui.Info.superclass.onRender.call(this, ct, position);
	}
});
Ext.reg('App.Ui.Info', App.Ui.Info);