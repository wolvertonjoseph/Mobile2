/**
 * Sencha Touch Example App
 *
 * @author Nils Dehl - mail@nils-dehl.de - http://www.nils-dehl.de
 * @version 1.0.0
 */

Ext.ns('App');

App = Ext.apply(new Ext.util.Observable,{

	/**
	 * UI Container object
	 *
	 * @type object
	 */
	ui: {},

	/**
	 * bootstrap
	 */
	bootstrap: function() {
		this.initUi();
		this.initEventListener();
	},

	/**
	 * init the application ui
	 */
	initUi: function() {
		this.ui = new App.Ui();
	},

	/**
	 * Init Event Listener
	 */
	initEventListener: function() {
	}
});